//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MyPad.rc
//
#define IDD_ABOUTBOX                    100
#define IDC_EDIT                        101
#define IDR_MAINFRAME                   128
#define IDR_MYPADTYPE                   129
#define ID_EDIT_DELETE                  32772
#define ID_FILE_OPEN32774               32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
