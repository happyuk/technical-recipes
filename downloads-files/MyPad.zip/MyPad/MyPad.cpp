// MyPad.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "MyPad.h"
#include "afxadv.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyPadApp

BEGIN_MESSAGE_MAP(CMyPadApp, CWinApp)
	//{{AFX_MSG_MAP(CMyPadApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)

	// Specific handling for the Recent File list
	ON_COMMAND_EX_RANGE(ID_FILE_MRU_FILE1, ID_FILE_MRU_FILE16, OnOpenRecentFile)

	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyPadApp construction

CMyPadApp::CMyPadApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMyPadApp object

CMyPadApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMyPadApp initialization

BOOL CMyPadApp::InitInstance()
{
	// Change the registry key under which our settings are stored.
	SetRegistryKey( _T("Local AppWizard-Generated Applications") );

	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;
	
	// Load standard ini file options, inc. Managing Recent Files list (MRU)
	LoadStdProfileSettings();

	// create and load the frame with its resources
	pFrame->LoadFrame(IDR_MAINFRAME,
		WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
		NULL);

	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMyPadApp message handlers





/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CMyPadApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CMyPadApp message handlers


//
// Function called when you save or load a file
//
void CMyPadApp::addToRecentFileList( CString path )
{
    AddToRecentFileList( path );
}


//
//function called when the user click on a recent file in the menu
//
CString CMyPadApp::getRecentFile( int index ) const
{
    return ( ( *m_pRecentFileList )[ index ] );
}

