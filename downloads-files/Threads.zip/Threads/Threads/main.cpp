#include <stdio.h>
#include <pthread.h>
#include <io.h>
#include <semaphore.h>
#include <time.h>
#include <string>
#include <queue>
#include <deque>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <Windows.h>

using namespace std;

FILE* output;

#define BILLION  1000000000L
#define EPSILON  0.00000001
#define DEBUG 1

// Used to keep track of older threads and their count
int thread_count = 0;

// Used to indicate which PID should be running
int process_to_run;
int ps_cpu_1;
int ps_cpu_2;

int g_time = 1;
double _clock = 1.0;

// Holds information of a thread for the scheduler
typedef struct {
  double quantum;        
  double remaining_time; 
  int arrival_time;      
  double duration;       
  int id;
  bool isReady;
  bool isFinished;
  double burst_time;     // total of time execution needed
} process_t;

std::deque<process_t> running_queue;
std::deque<process_t> waiting_queue;
pthread_mutex_t thread_flag_mutex;
pthread_cond_t thread_flag_cv;

LARGE_INTEGER getFILETIMEoffset()
{
    SYSTEMTIME s;
    FILETIME f;
    LARGE_INTEGER t;

    s.wYear = 1970;
    s.wMonth = 1;
    s.wDay = 1;
    s.wHour = 0;
    s.wMinute = 0;
    s.wSecond = 0;
    s.wMilliseconds = 0;
    SystemTimeToFileTime(&s, &f);
    t.QuadPart = f.dwHighDateTime;
    t.QuadPart <<= 32;
    t.QuadPart |= f.dwLowDateTime;
    return (t);
}

int clock_gettime(int X, struct timeval *tv)
{
    LARGE_INTEGER           t;
    FILETIME            f;
    double                  microseconds;
    static LARGE_INTEGER    offset;
    static double           frequencyToMicroseconds;
    static int              initialized = 0;
    static BOOL             usePerformanceCounter = 0;

    if (!initialized) {
        LARGE_INTEGER performanceFrequency;
        initialized = 1;
        usePerformanceCounter = QueryPerformanceFrequency(&performanceFrequency);
        if (usePerformanceCounter) {
            QueryPerformanceCounter(&offset);
            frequencyToMicroseconds = (double)performanceFrequency.QuadPart / 1000000.;
        } else {
            offset = getFILETIMEoffset();
            frequencyToMicroseconds = 10.;
        }
    }
    if (usePerformanceCounter) QueryPerformanceCounter(&t);
    else {
        GetSystemTimeAsFileTime(&f);
        t.QuadPart = f.dwHighDateTime;
        t.QuadPart <<= 32;
        t.QuadPart |= f.dwLowDateTime;
    }

    t.QuadPart -= offset.QuadPart;
    microseconds = (double)t.QuadPart / frequencyToMicroseconds;
    t.QuadPart = microseconds;
    tv->tv_sec = t.QuadPart / 1000000;
    tv->tv_usec = t.QuadPart % 1000000;
    return (0);
}

void set_thread_flag(int flag_value)
{
  pthread_mutex_lock(&thread_flag_mutex);
  // Set thread value, then signal in case run_process is blocked waiting for flag to be set
  process_to_run = flag_value;
  pthread_cond_broadcast(&thread_flag_cv);
 
  pthread_mutex_unlock(&thread_flag_mutex);
}

void checkArrivalTime()
{
  for (int i = 0; i < waiting_queue.size(); i++) 
  {
    // check for arrival time
    if(waiting_queue.front().arrival_time == g_time) 
	{
      running_queue.push_back(waiting_queue.front());
      //log(waiting_queue.front().id, "starting");
      waiting_queue.pop_front();
    } else 
	{
      break;
    }
  }
}

void print_queue(std::deque<process_t> queue)
{
	for (unsigned i = 0; i < queue.size(); i++) 
	{
		std::cout << "id = " << queue.at(i).id << ", arrival = " << queue[i].arrival_time <<
					", remaining time = " << queue[i].remaining_time <<
					", execution time = " << queue[i].duration;
	}
}

void start_rr()
{
	bool areProcessFinished;
	std::cout << "Starting round-robin scheduler" << std::endl;

	while(1) 
	{
		areProcessFinished = true;
		checkArrivalTime();

		// Run all processes in run queue
		for (int i = 0; i < running_queue.size(); i++) 
		{
			if (!running_queue[i].isFinished) 
			{
				// Wake first pid in queue and give it the CPU
				if(DEBUG) print_queue(running_queue);
				set_thread_flag(running_queue[i].id);

				// Sleep until cpu is returned to scheduler
				pthread_mutex_lock(&thread_flag_mutex);
				while (process_to_run != 0) 
				{
					pthread_cond_wait(&thread_flag_cv, &thread_flag_mutex);
				}

				pthread_mutex_unlock(&thread_flag_mutex);
				printf("Scheduler resumed\n");
				g_time++;
				checkArrivalTime();
			}
		}

		if (waiting_queue.size() == 0) 
		{
			for (int i = 0 ; i < running_queue.size() ; ++i) 
			{
				if (!running_queue[i].isFinished) 
				{
					areProcessFinished = false;
				}
			}
		} 
		else 
		{
			areProcessFinished = false;
		}

		if (areProcessFinished)	
			break;
	}
}

void init_flag()
{
	pthread_mutex_init(&thread_flag_mutex, NULL);
	pthread_cond_init(&thread_flag_cv, NULL);
	process_to_run = 0;
}


int read_input(const char* filename)
{
	FILE* fp;
	int y;
	float i;

	fp = fopen(filename, "r");
	if (!fp) 
	{
		std::cout << "Could not open file" << std::endl;
		return -1;
	}

	// Assign input to array
	while ( fscanf (fp, "%d %f", &y, &i ) != EOF )
	{
		process_t* temp = new process_t;
		temp->duration = 0.0;
		temp->isFinished = temp->isReady = false;
		temp->arrival_time = y;
		temp->remaining_time = temp->burst_time = i;
		temp->id = ++thread_count;
		waiting_queue.push_back(*temp);
	}

	fclose(fp);
	return 1;
}

void log(int processId, char* state)
{
	output = fopen("output.txt", "a");
	fprintf(output, "Time: %d, Process %d: %s\n", g_time, processId, state);
	fclose(output);
}


void* run_process(void* a)
{
	process_t* info = (process_t*)a;
	int id = 0;

	// Run thread until reaches total burst time
	printf("process started with burst time %.3f\n", info->burst_time);
	while(info->burst_time - info->duration > EPSILON) 
	{
		// Lock mutex before accessing flag value
		pthread_mutex_lock(&thread_flag_mutex);
		// Check if the current thread is given CPU

		while (process_to_run != info->id) {
			pthread_cond_wait(&thread_flag_cv, &thread_flag_mutex);
	}

    pthread_mutex_unlock(&thread_flag_mutex);

//    log(info->id, "resumed");
    std::cout << "Time " << g_time << 
		      ", Process " << info->id << "resumed with remaining time " << info->remaining_time;
    struct timespec start, stop;
    double runTime = 0.0;

 /*   if( clock_gettime( CLOCK_REALTIME, &start) == -1 ) {
      perror( "clock gettime" );
      return NULL;
    }*/

	LARGE_INTEGER frequency;
    LARGE_INTEGER starttime;
    LARGE_INTEGER endtime;
    double elapsedSeconds;
    QueryPerformanceFrequency(&frequency);
    QueryPerformanceCounter(&starttime);
    
    

    // Run for 10% of remaining time
    double quantum = 0.3;
	while(runTime < quantum) 
	{
		QueryPerformanceCounter(&endtime);
		elapsedSeconds = (endtime.QuadPart - starttime.QuadPart) / (double)frequency.QuadPart;
		runTime = elapsedSeconds;

		/*  if( clock_gettime( CLOCK_REALTIME, &stop) == -1 ) {
			perror( "clock gettime" );
			return NULL;
		  }
		  runTime = ( stop.tv_sec - start.tv_sec )
				 + (double)( stop.tv_nsec - start.tv_nsec )
				   / (double)BILLION;  */
		}

		info->duration += quantum;
		info->remaining_time -= quantum;

		for (int i = 0 ; i < running_queue.size() ; ++i) 
		{
		  if (running_queue[i].id == info->id) 
		  {
			id = i;
		  }
		}

		if (running_queue.size() > 0 )
		{
			running_queue[id].duration = info->duration;
			running_queue[id].remaining_time = info->remaining_time;
		}

	   if(DEBUG)
		  printf( "Run time: %lf\n", quantum);
		log(info->id, "paused");
		printf("Time %d, Process %d paused with remaining time: %.3f\n", g_time, info->id, info->remaining_time);
		// Return CPU to scheduler
		set_thread_flag(0);
	}

	info->isFinished = running_queue[id].isFinished = true;
	printf("Time %d, Process %d finished with run time %.3f\n", g_time, info->id, info->duration);
	log(info->id, "finished");
	
    return 0;
}


int main(int argc, const char *argv[])
{
	read_input("input.txt");
	init_flag();
	pthread_t threads[1];
	std::cout << _clock << std::endl;

	for (int i = 0; i < thread_count; i++)
	{
		pthread_create(&threads[i], NULL, run_process, (void*)&waiting_queue[i]);
	}

	set_thread_flag(2);
	
	// Sleep until cpu is returned to scheduler
	pthread_mutex_lock(&thread_flag_mutex);
	while (process_to_run != 0) 
	{
		pthread_cond_wait(&thread_flag_cv, &thread_flag_mutex);
	}
	pthread_mutex_unlock(&thread_flag_mutex);
  
  if (argc == 2) {
    const char* filepath = argv[1];
    read_input(filepath);
    init_flag();
    pthread_t threads[1];

    for (int i = 0; i < thread_count; i++) {
      pthread_create(&threads[i], NULL, run_process, (void*)&waiting_queue[i]);
    }
    start_rr();
    output = fopen("output.txt", "a");
    for (int i = 0; i < running_queue.size(); i++) {
        fprintf(output, "Process %d has initial burst time %.3f\n"
            , running_queue[i].id, running_queue[i].duration);
        printf("Process %d has initial burst time %.3f\n"
            , running_queue[i].id, running_queue[i].duration);
    }

    fclose(output);

  } else {
    printf ("wrong number of arguments passed, program should be used as following:\n");
    printf ("./assignment2 <input_filename>\n");
  }
  
  return 0;
}

