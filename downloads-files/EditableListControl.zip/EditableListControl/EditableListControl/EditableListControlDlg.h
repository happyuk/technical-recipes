

// EditableListControlDlg.h : header file
//

#pragma once

#include "EditableListCtrl.h"

// CEditableListControlDlg dialog
class CEditableListControlDlg : public CDialogEx
{
// Construction
public:
	CEditableListControlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_EDITABLELISTCONTROL_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnNMClickList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg LRESULT OnNotifyDescriptionEdited(WPARAM, LPARAM);
	
	CPoint InterviewListCursorPosition() const;

	DECLARE_MESSAGE_MAP()

	CEditableListCtrl m_EditableList;
	bool m_fClickedList;
};
