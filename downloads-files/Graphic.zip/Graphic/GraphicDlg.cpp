// GraphicDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Graphic.h"
#include "GraphicDlg.h"
#include ".\graphicdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGraphicDlg dialog



CGraphicDlg::CGraphicDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGraphicDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	display = false;
}

void CGraphicDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CGraphicDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// CGraphicDlg message handlers

BOOL CGraphicDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGraphicDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		if ( display )
		{
			// device context for painting
	        CPaintDC dc(this);

			CPen pen( PS_SOLID, 
				      1, 
				      RGB( 0, 0, 0 ) );
			dc.SelectStockObject(BLACK_BRUSH);	

			// Draw some lines...					   
			dc.MoveTo( 100, 50 );
		    dc.LineTo( 200, 52 );	
			dc.MoveTo( 105, 47 );
		    dc.LineTo( 202, 60 );
			dc.MoveTo( 85,  85 );
		    dc.LineTo( 178, 64 );
			dc.MoveTo( 75,  99 );
		    dc.LineTo( 128, 66 );

			// Draw some ellipses
			dc.Ellipse( 250, 118, 254, 114 );	
			dc.Ellipse( 255, 138, 260, 133 );	
			dc.Ellipse( 260, 148, 265, 153 );	
			dc.Ellipse( 240, 177, 248, 173 );	
			dc.Ellipse( 259, 158, 263, 162 );	
		}

		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGraphicDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CGraphicDlg::OnBnClickedOk()
{
	display = true;

	// Re-draw the window	
	RedrawWindow( 0, 0, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE );	
}
