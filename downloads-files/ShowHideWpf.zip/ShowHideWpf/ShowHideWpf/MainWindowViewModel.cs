﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ShowHideWpf
{
    public class MainWindowViewModel
    {
        private bool _showButton;

        public MainWindowViewModel()
        {
            // Set this to true or false depending on how you wish to set the
            // visibility of the WPF control.
            _showButton = true;
        }

        public bool ShowButton        
        {
            get { return _showButton; }
        }
    }
}
