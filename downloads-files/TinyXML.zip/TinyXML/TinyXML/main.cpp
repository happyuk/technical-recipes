#include "tinyxml.h"	
#include <string>
#include <iostream>

int main(void)
{
	TiXmlDocument doc( "test1.xml" );
	doc.LoadFile();

	TiXmlElement *l_pRootElement = doc.RootElement();

    if( NULL != l_pRootElement )
    {
		// set of <person> tags
		TiXmlElement *l_pPeople = l_pRootElement->FirstChildElement( "people" );

		if ( NULL != l_pPeople )
		{
			TiXmlElement *l_pPerson = l_pPeople->FirstChildElement( "person" );

			while( l_pPerson )
			{
				TiXmlElement *l_pForename = l_pPerson->FirstChildElement( "forename" );

				if ( NULL != l_pForename )
				{
					std::cout << l_pForename->GetText();
				}

				TiXmlElement *l_pSurname = l_pPerson->FirstChildElement( "surname" );

				if ( NULL != l_pSurname )
				{
					std::cout << " " << l_pSurname->GetText();
				}

				std::cout << std::endl;

				l_pPerson = l_pPerson->NextSiblingElement( "person" );
			}
		}
	}

	// Same reading of the <person> tags, but this time using handles
	// to make it a little more concise
	TiXmlHandle docHandle( &doc );

	TiXmlElement* l_pPerson = docHandle.FirstChild( "file" ).FirstChild( "people" ).Child( "person", 0 ).ToElement();
	
	while( l_pPerson )
	{
		TiXmlElement *l_pForename = l_pPerson->FirstChildElement( "forename" );

		if ( NULL != l_pForename )
		{
			std::cout << l_pForename->GetText();
		}

		TiXmlElement *l_pSurname = l_pPerson->FirstChildElement( "surname" );

		if ( NULL != l_pSurname )
		{
			std::cout << " " << l_pSurname->GetText();
		}

		std::cout << std::endl;

		l_pPerson = l_pPerson->NextSiblingElement( "person" );
	}

	return 0;
}