
// SerializeSDIexample.h : main header file for the SerializeSDIexample application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CSerializeSDIexampleApp:
// See SerializeSDIexample.cpp for the implementation of this class
//

class CSerializeSDIexampleApp : public CWinAppEx
{
public:
	CSerializeSDIexampleApp();


// Overrides
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

// Implementation
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CSerializeSDIexampleApp theApp;
