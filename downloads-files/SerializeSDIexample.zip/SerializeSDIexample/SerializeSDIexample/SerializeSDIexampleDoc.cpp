
// SerializeSDIexampleDoc.cpp : implementation of the CSerializeSDIexampleDoc class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "SerializeSDIexample.h"
#endif

#include "SerializeSDIexampleDoc.h"

#include <propkey.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CSerializeSDIexampleDoc

IMPLEMENT_DYNCREATE(CSerializeSDIexampleDoc, CDocument)

BEGIN_MESSAGE_MAP(CSerializeSDIexampleDoc, CDocument)
END_MESSAGE_MAP()


// CSerializeSDIexampleDoc construction/destruction

CSerializeSDIexampleDoc::CSerializeSDIexampleDoc()
{
	// TODO: add one-time construction code here
	m_strData = "";
}

CSerializeSDIexampleDoc::~CSerializeSDIexampleDoc()
{
}

BOOL CSerializeSDIexampleDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CSerializeSDIexampleDoc serialization

void CSerializeSDIexampleDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		ar << m_strData;
	}
	else
	{
		ar >> m_strData;
	}
}

#ifdef SHARED_HANDLERS

// Support for thumbnails
void CSerializeSDIexampleDoc::OnDrawThumbnail(CDC& dc, LPRECT lprcBounds)
{
	// Modify this code to draw the document's data
	dc.FillSolidRect(lprcBounds, RGB(255, 255, 255));

	CString strText = _T("TODO: implement thumbnail drawing here");
	LOGFONT lf;

	CFont* pDefaultGUIFont = CFont::FromHandle((HFONT) GetStockObject(DEFAULT_GUI_FONT));
	pDefaultGUIFont->GetLogFont(&lf);
	lf.lfHeight = 36;

	CFont fontDraw;
	fontDraw.CreateFontIndirect(&lf);

	CFont* pOldFont = dc.SelectObject(&fontDraw);
	dc.DrawText(strText, lprcBounds, DT_CENTER | DT_WORDBREAK);
	dc.SelectObject(pOldFont);
}

// Support for Search Handlers
void CSerializeSDIexampleDoc::InitializeSearchContent()
{
	CString strSearchContent;
	// Set search contents from document's data. 
	// The content parts should be separated by ";"

	// For example:  strSearchContent = _T("point;rectangle;circle;ole object;");
	SetSearchContent(strSearchContent);
}

void CSerializeSDIexampleDoc::SetSearchContent(const CString& value)
{
	if (value.IsEmpty())
	{
		RemoveChunk(PKEY_Search_Contents.fmtid, PKEY_Search_Contents.pid);
	}
	else
	{
		CMFCFilterChunkValueImpl *pChunk = NULL;
		ATLTRY(pChunk = new CMFCFilterChunkValueImpl);
		if (pChunk != NULL)
		{
			pChunk->SetTextValue(PKEY_Search_Contents, value, CHUNK_TEXT);
			SetChunkValue(pChunk);
		}
	}
}

#endif // SHARED_HANDLERS

// CSerializeSDIexampleDoc diagnostics

#ifdef _DEBUG
void CSerializeSDIexampleDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSerializeSDIexampleDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CSerializeSDIexampleDoc commands
