
// SerializeSDIexampleView.h : interface of the CSerializeSDIexampleView class
//

#pragma once


class CSerializeSDIexampleView : public CView
{
protected: // create from serialization only
	CSerializeSDIexampleView();
	DECLARE_DYNCREATE(CSerializeSDIexampleView)

// Attributes
public:
	CSerializeSDIexampleDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// Implementation
public:
	virtual ~CSerializeSDIexampleView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	afx_msg void OnFilePrintPreview();
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
};

#ifndef _DEBUG  // debug version in SerializeSDIexampleView.cpp
inline CSerializeSDIexampleDoc* CSerializeSDIexampleView::GetDocument() const
   { return reinterpret_cast<CSerializeSDIexampleDoc*>(m_pDocument); }
#endif

