
// SerializeSDIexampleView.cpp : implementation of the CSerializeSDIexampleView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "SerializeSDIexample.h"
#endif

#include "SerializeSDIexampleDoc.h"
#include "SerializeSDIexampleView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSerializeSDIexampleView

IMPLEMENT_DYNCREATE(CSerializeSDIexampleView, CView)

BEGIN_MESSAGE_MAP(CSerializeSDIexampleView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CSerializeSDIexampleView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_CHAR()
END_MESSAGE_MAP()

// CSerializeSDIexampleView construction/destruction

CSerializeSDIexampleView::CSerializeSDIexampleView()
{
	// TODO: add construction code here

}

CSerializeSDIexampleView::~CSerializeSDIexampleView()
{
}

BOOL CSerializeSDIexampleView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CSerializeSDIexampleView drawing

void CSerializeSDIexampleView::OnDraw(CDC* pDC)
{
	CSerializeSDIexampleDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
	pDC->TextOut( 0, 0, pDoc->m_strData );
}


// CSerializeSDIexampleView printing


void CSerializeSDIexampleView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CSerializeSDIexampleView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSerializeSDIexampleView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSerializeSDIexampleView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CSerializeSDIexampleView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CSerializeSDIexampleView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CSerializeSDIexampleView diagnostics

#ifdef _DEBUG
void CSerializeSDIexampleView::AssertValid() const
{
	CView::AssertValid();
}

void CSerializeSDIexampleView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSerializeSDIexampleDoc* CSerializeSDIexampleView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSerializeSDIexampleDoc)));
	return (CSerializeSDIexampleDoc*)m_pDocument;
}
#endif //_DEBUG


// CSerializeSDIexampleView message handlers


void CSerializeSDIexampleView::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: Add your message handler code here and/or call default
	CSerializeSDIexampleDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	if ( nChar == 8 )
	{
		int length = pDoc->m_strData.GetLength();
		CString str = pDoc->m_strData.Left( length - 1 );
		pDoc->m_strData = str;
	}
	else
	{
		CString str;
		str.Format( TEXT( "%c" ), nChar );
		pDoc->m_strData += str;
	}
	Invalidate();
	pDoc->SetModifiedFlag();

	CView::OnChar(nChar, nRepCnt, nFlags);
}
