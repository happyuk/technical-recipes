
// ListViewDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ListView.h"
#include "ListViewDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CListViewDlg dialog




CListViewDlg::CListViewDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CListViewDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CListViewDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST1, m_List);
}

BEGIN_MESSAGE_MAP(CListViewDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
END_MESSAGE_MAP()


// CListViewDlg message handlers

BOOL CListViewDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// Ask Mfc to create/insert a column
	m_List.InsertColumn(	
				0,				// Rank/order of item
				"Name",			// Caption for this header
				LVCFMT_LEFT,	// Relative position of items under header
				100 );			// Width of items under header

	m_List.InsertColumn( 1, "Profession", LVCFMT_CENTER, 80 );
	m_List.InsertColumn( 2, "Fav. Sport", LVCFMT_LEFT, 100 );
	m_List.InsertColumn( 3, "Hobby", LVCFMT_LEFT, 80 );

	int nItem;

	nItem = m_List.InsertItem( 0, "Sandra C. Anschwitz" );
	m_List.SetItemText( nItem, 1, "Singer" );
	m_List.SetItemText( nItem, 2, "HandBall" );
	m_List.SetItemText( nItem, 3, "Beach" );

	nItem = m_List.InsertItem(0, "Roger A. Miller" );
	m_List.SetItemText( nItem, 1, "FootBaller" );
	m_List.SetItemText( nItem, 2, "Tennis" );
	m_List.SetItemText( nItem, 3, "Teaching" );

	nItem = m_List.InsertItem(0, "Marie-Julie W. Gross" );
	m_List.SetItemText( nItem, 1, "Student" );
	m_List.SetItemText( nItem, 2, "Boxing" );
	m_List.SetItemText( nItem, 3, "Programming" );

	nItem = m_List.InsertItem(0, "Ella Pius Roger" );
	m_List.SetItemText( nItem, 1, "Architect" );
	m_List.SetItemText( nItem, 2, "Ping-Pong" );
	m_List.SetItemText( nItem, 3, "Songo" );

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CListViewDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CListViewDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

