#include "Graph.h"
#include <iostream>

// A structure to represent a subset for union-find
struct subset
{
    int parent;
    int rank;
};
typedef subset Subset;

// A utility function to find set of an element i
// (uses path compression technique)
int Find( Subset subsets[], int i )
{
    // find root and make root as parent of i (path compression)
    if (subsets[i].parent != i)
        subsets[i].parent = Find(subsets, subsets[i].parent);
 
    return subsets[i].parent;
}

// A function that does union of two sets of x and y by rank
void Union( Subset subsets[], int x, int y )
{
    int xroot = Find( subsets, x );
    int yroot = Find( subsets, y );
 
    // Attach smaller rank tree under root of high rank tree
    // (Union by Rank)
    if ( subsets[xroot].rank < subsets[yroot].rank )
	{
        subsets[xroot].parent = yroot;
	}
    else if (subsets[xroot].rank > subsets[yroot].rank)
	{
        subsets[yroot].parent = xroot;
	}
    else
    {
		// If ranks are same, then make one as root and increment
		// its rank by one
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

// The main function to construct MST using Kruskal's algorithm
void KruskalMST( DenseGRAPH<Edge>* graph, std::vector<EdgePtr>& mst )
{
    const int V = graph->V();
 
    // Sort edges in non-decreasing order of their weight
	std::vector<EdgePtr> edges;
	graph->edges( edges );
	std::sort(edges.begin(), edges.end(), EdgeSort() );
 
    // Allocate memory for creating V ssubsets
	std::unique_ptr<subset[]> subsets( new subset[ V ]() );
 
    // Create V subsets with single elements
    for ( int v = 0; v < V; ++v )
    {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }
 
	for ( std::vector<EdgePtr>::iterator it = edges.begin(); it != edges.end(); ++it )
	{
		EdgePtr edgePtr = *it;

		int x = Find( subsets.get(), edgePtr->v );
		int y = Find( subsets.get(), edgePtr->w );

		// If including this edge does't cause cycle, include it
		// in result and increment the index of result for next edge
		if ( x != y )
		{
			mst.push_back( edgePtr );
			Union( subsets.get(), x, y );
		}
	}
}

int main()
{
	DenseGRAPH<Edge>* graph = new DenseGRAPH<Edge>( 11, true ); 

	graph->insert( EdgePtr( new Edge( 0, 1, 1.0 ) ) );    
	graph->insert( EdgePtr( new Edge( 0, 2, 0.6) ) );    
	graph->insert( EdgePtr( new Edge( 0, 3, 1.0 ) ) );   
	graph->insert( EdgePtr( new Edge( 0, 4, 1.0 ) ) );    
	graph->insert( EdgePtr( new Edge( 0, 5, 1.1 ) ) );   
	graph->insert( EdgePtr( new Edge( 1, 4, 1.8 ) ) );   
	graph->insert( EdgePtr( new Edge( 1, 10, 1.9 ) ) );   
	graph->insert( EdgePtr( new Edge( 2, 3, 2.1 ) ) );   
	graph->insert( EdgePtr( new Edge( 2, 5, 2.3) ) );   
	graph->insert( EdgePtr( new Edge( 2, 6, 1.7 ) ) );   
	graph->insert( EdgePtr( new Edge( 3, 4, 1.7 ) ) );  
	graph->insert( EdgePtr( new Edge( 5, 6, 0.5 ) ) );  
	graph->insert( EdgePtr( new Edge( 5, 7, 0.7 ) ) );  
	graph->insert( EdgePtr( new Edge( 5, 8, 0.9 ) ) );  
	graph->insert( EdgePtr( new Edge( 5, 9, 0.9 ) ) );  
	graph->insert( EdgePtr( new Edge( 5, 10, 1.0 ) ) );     
	graph->insert( EdgePtr( new Edge( 6, 7, 1.9 ) ) );  
	graph->insert( EdgePtr( new Edge( 7, 8, 1.7 ) ) );  
	graph->insert( EdgePtr( new Edge( 8, 9, 1.6 ) ) );  
	graph->insert( EdgePtr( new Edge( 9, 10, 2.2 ) ) );  

	std::vector<EdgePtr> mst;
	KruskalMST( graph, mst );

	for ( std::vector<EdgePtr>::const_iterator it = mst.begin(); it != mst.end(); ++it )
	{
		std::cout << it->get()->v << " " 
			      << it->get()->w << " "
				  << it->get()->wt << std::endl;
	}

 
	return 0;
}