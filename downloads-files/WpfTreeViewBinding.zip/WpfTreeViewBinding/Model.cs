﻿using System.Collections.Generic;

namespace WpfTreeViewBinding.Model
{
    public class Item
    {
        public string Name { get; set; }
    }

    public class DirectoryItem : Item
    {
        public DirectoryItem()
        {
            Items = new List<DirectoryItem>();
        }

        public List<DirectoryItem> Items { get; set; }

        public void AddDirItem(DirectoryItem directoryItem)
        {
            Items.Add(directoryItem);
        }

        public List<Item> Traverse(DirectoryItem it)
        {
            var items = new List<Item>();

            foreach (var itm in it.Items)
            {
                Traverse(itm);
                items.Add(itm);
            }

            return items;
        }
    }
}