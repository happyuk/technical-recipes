%include <typemaps/cpointer.swg>
