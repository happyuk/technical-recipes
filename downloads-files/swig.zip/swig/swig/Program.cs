﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace swig
{
    class Program
    {
        static void Main(string[] args)
        {
            var cpp = new cpp_file();
            Console.WriteLine("Five times ten = " + cpp.times2(5));  
        }
    }
}
