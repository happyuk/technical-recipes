#include <iostream>
#include <boost/function.hpp>


boost::function<float (int x, int y)> f;

struct int_div 
{ 
	float operator()(int x, int y) const { return ((float)x)/y; }; 
};


int main()
{
	f = int_div();

	std::cout << f(5, 3) << std::endl;


	return 0;
}