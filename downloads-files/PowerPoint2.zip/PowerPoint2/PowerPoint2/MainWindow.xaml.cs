﻿using System.Windows;
using System.Windows.Controls;

namespace PowerPoint2
{
    public partial class MainWindow
    {
        private static DocumentViewer _docViewer;

        public MainWindow()
        {           
            InitializeComponent();
            WindowState = WindowState.Maximized;
            _docViewer = DocumentViewPowerPoint;
        }

        public static DocumentViewer GetInstance()
        {
            return _docViewer;
        }
    }
}