﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Xps.Packaging;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.PowerPoint;
using Application = Microsoft.Office.Interop.PowerPoint.Application;

namespace PowerPoint2
{
    public class MainWindowViewModel : ViewModelBase
    {
        private IDocumentPaginatorSource _documentViewer;
        private ICommand _fitPageCommand;
        private ICommand _nextSlideCommand;
        private ICommand _prevSlideCommand;

        public MainWindowViewModel()
        {
            const string powerPointFile = @"c:\temp\ppt.pptx";

            if (!File.Exists(powerPointFile))
            {
               MessageBox.Show("File does not exist: " + powerPointFile);
               return;
            }

            var xpsFile = Path.GetTempPath() + Guid.NewGuid() + ".xps";
            var xpsDocument = ConvertPowerPointToXps(powerPointFile, xpsFile);

            DocViewer = xpsDocument.GetFixedDocumentSequence();
        }

        public IDocumentPaginatorSource DocViewer
        {
            get { return _documentViewer; }
            set
            {
                _documentViewer = value;
                OnPropertyChanged("DocViewer");
            }
        }

        public ICommand FitPageCommand
        {
            get
            {
                return _fitPageCommand ?? (_fitPageCommand = new RelayCommand(
                           x =>
                           {
                               var docViewerInstance = MainWindow.GetInstance();
                               docViewerInstance.FitToMaxPagesAcross(1);
                           }));
            }
        }

        public ICommand NextSlideCommand
        {
            get
            {
                return _nextSlideCommand ?? (_nextSlideCommand = new RelayCommand(
                           x =>
                           {
                               var docViewerInstance = MainWindow.GetInstance();
                               docViewerInstance.NextPage();
                           }));
            }
        }

        public ICommand PreviousSlideCommand
        {
            get
            {
                return _prevSlideCommand ?? (_prevSlideCommand = new RelayCommand(
                           x =>
                           {
                               var docViewerInstance = MainWindow.GetInstance();
                               docViewerInstance.PreviousPage();
                           }));
            }
        }

        private static XpsDocument ConvertPowerPointToXps(string pptFilename, string xpsFilename)
        {
            var pptApp = new Application();

            var presentation = pptApp.Presentations.Open(pptFilename, MsoTriState.msoTrue, MsoTriState.msoFalse,
                MsoTriState.msoFalse);

            try
            {
                presentation.ExportAsFixedFormat(xpsFilename, PpFixedFormatType.ppFixedFormatTypeXPS);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to export to XPS format: " + ex);
            }
            finally
            {
                presentation.Close();
                pptApp.Quit();
            }

            return new XpsDocument(xpsFilename, FileAccess.Read);
        }
    }
}