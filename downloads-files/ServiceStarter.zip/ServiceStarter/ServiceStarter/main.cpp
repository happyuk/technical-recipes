#include <iostream>
#include <direct.h>
#include <afx.h>

const int MAX_READ_BUFFER = 4096;
 
int main( int argc, char *argv[] )
{
	// Obtain location of system directory eg C:\Windows\System32
	TCHAR systemDirPath[MAX_PATH] = _T("");
    GetSystemDirectory( systemDirPath, sizeof(systemDirPath)/sizeof(_TCHAR) );

	// Set location of sc.exe
	CString strExePath;
	strExePath.Format( "%s%s", systemDirPath, "\\sc.exe" );

    // Create security attributes needed to create the pipe
    HANDLE hChildStdoutRd;
    HANDLE hChildStdoutWr;
    SECURITY_ATTRIBUTES saAttr = { sizeof(SECURITY_ATTRIBUTES) } ;
    saAttr.bInheritHandle  = TRUE;
    saAttr.lpSecurityDescriptor = NULL;
     
    // Create pipe to get results from child process stdou\t, return if unsuccessful
    if ( !CreatePipe( &hChildStdoutRd, &hChildStdoutWr, &saAttr, 0 ) )
    {
        return 1;
    }
    
	// Default if no command line arguments supplied
    CString l_strParameters = argc < 2 ? " QUERY \"Themes\"" : argv[ 1 ]; 
 
    PROCESS_INFORMATION pif  = { 0 };
    STARTUPINFO si = { sizeof(STARTUPINFO) };
 
    ZeroMemory( &si,sizeof( si ) );  
    si.cb = sizeof( si ); 
    si.dwFlags     = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
    si.hStdOutput  = hChildStdoutWr;
    si.hStdError   = hChildStdoutWr;
    si.wShowWindow = SW_HIDE;
 
    BOOL bRet = CreateProcess(
                        strExePath.GetBuffer(0),       // Path to ffprobe executable
                        l_strParameters.GetBuffer(0),  // Command parameters string
                        NULL,                          // Process handle not inherited
                        NULL,                          // Thread handle not inherited
                        TRUE,                          // Inheritance of handles
                        CREATE_NO_WINDOW,              // Suppress console window
                        NULL,                          // Same environment block as this prog
                        NULL,                          // Current directory
                        &si,                           // Pointer to STARTUPINFO
                        &pif );                        // Pointer to PROCESS_INFORMATION
 
    if( bRet == FALSE )
    {      
        return false;
    }
 
    // Wait until child processes exit, but not forever.  Terminate if still running.
    WaitForSingleObject( pif.hProcess, 4000 );
    TerminateProcess( pif.hProcess, 0 );
 
    // Close the write end of the pipe before reading from the read end of the pipe.
    if ( !CloseHandle( hChildStdoutWr ) )
    {
        return false;
    }
 
    // Read output chunks from the child process.
    CString l_strResult;
    for ( ;; )
    {
        DWORD l_dwRead;
        CHAR l_chBuffer[ MAX_READ_BUFFER ];
                 
        bool l_fIsDone = !ReadFile( 
								hChildStdoutRd, 
								l_chBuffer, 
								MAX_READ_BUFFER, 
								&l_dwRead, NULL) || l_dwRead == 0;
         
        if( l_fIsDone ) break;
                 
        l_strResult += CString( l_chBuffer, l_dwRead) ;
    }
 
    CloseHandle( hChildStdoutRd );
    CloseHandle( pif.hProcess ); 
    CloseHandle( pif.hThread );   

    std::cout << l_strResult << std::endl;
 
    std::getchar();
    return 0;
}

