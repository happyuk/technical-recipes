﻿using System;
using System.Drawing.Imaging;
using System.Drawing;
using System.Windows.Media.Imaging;
using System.Windows;

namespace MVVM
{
    public static class BitmapConversion
    {
        public static BitmapSource BitmapToBitmapSource(Bitmap source)
        {
            return System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                          source.GetHbitmap(),
                          IntPtr.Zero,
                          Int32Rect.Empty,
                          BitmapSizeOptions.FromEmptyOptions());
        }
    }

    public class MainWindowViewModel
    {
        private BitmapSource _bitmapSource;

        public MainWindowViewModel()
        {
            Bitmap bitmap = (Bitmap)Bitmap.FromFile(@"c:\dump\bulb.png", true);
            _bitmapSource = BitmapConversion.BitmapToBitmapSource(bitmap);
        }

        public BitmapSource ButtonSource
        {
            get { return _bitmapSource; }
        }
    }
}